class Constants {
  static const String api_key =
      'ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SmpiR0Z6Y3lJNklrMWxjbU5vWVc1MElpd2ljSEp2Wm1sc1pWOXdheUk2T1Rnek1EazRMQ0p1WVcxbElqb2lNVGN4T1RjMk16ZzVOUzQyT1RZM09ESWlmUS5OUUZyVDY1Q1ZRLWF6OFNleHB6OFAwWjk0TDMwRldPR2RCT0xpQ0JzOVpldFRLNjBoNXVsRkZXVVN1X1VFZWNEaWFIY3cxazh5UHJZZER2ZkVzWmdpZw===';
  static const String integration_id = '4602033'; // Add this line
}
