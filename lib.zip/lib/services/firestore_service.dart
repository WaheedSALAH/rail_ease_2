import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:rail_ease/services/paymob/ticketdata/ticket_data.dart';

class FirestoreService {
  final CollectionReference trainsCollection =
      FirebaseFirestore.instance.collection('trains');

  Stream<List<TicketData>> getTickets(String trainNumber) {
    return trainsCollection
        .doc(trainNumber)
        .collection('tickets')
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) =>
                TicketData.fromFirestore(doc.data() as Map<String, dynamic>))
            .toList());
  }

  Future<void> saveTicketToSubcollection(TicketData ticket) async {
    final docRef = trainsCollection.doc(ticket.trainNumber);
    await docRef.collection('tickets').add(ticket.toMap());
  }

  Future<void> addTicket(
      Map<String, dynamic> trainData, TicketData ticket) async {
    final docRef = trainsCollection.doc(ticket.trainNumber);
    await docRef.set(trainData); // Save train data
    await docRef.collection('tickets').add(ticket.toMap()); // Save ticket data
  }

  Future<void> saveTicketData(TicketData ticketData) async {
    final docRef = trainsCollection.doc(ticketData.trainNumber);
    await docRef.collection('tickets').add(ticketData.toMap());
  }

  Future<List<Map<String, dynamic>>> getStations() async {
    final QuerySnapshot snapshot =
        await FirebaseFirestore.instance.collection('stations').get();
    return snapshot.docs
        .map((doc) => doc.data() as Map<String, dynamic>)
        .toList();
  }

  getTicketData(String trainNumber) {}
}
