import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:rail_ease/services/firestore_service.dart';
import 'package:rail_ease/services/paymob/ticketdata/ticket_data.dart';

class MyTicket extends StatefulWidget {
  final String trainNumber;
  final int totalPrice;
  final String date;

  MyTicket({
    required this.trainNumber,
    required this.totalPrice,
    required this.date,
  });

  @override
  _MyTicketState createState() => _MyTicketState();
}

class _MyTicketState extends State<MyTicket> {
  final FirestoreService _firestoreService = FirestoreService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ticket Details'),
      ),
      body: FutureBuilder<TicketData>(
        future: _firestoreService.getTicketData(widget.trainNumber),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data == null) {
            return Center(
                child: Text('No ticket found for train ${widget.trainNumber}'));
          }

          TicketData ticket = snapshot.data!;

          // Save ticket to subcollection
          _firestoreService.saveTicketToSubcollection(
            ticket.copyWith(
              ticketPrice: widget.totalPrice,
              date: widget.date,
            ),
          );

          return Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Color(0xFFFFFFFF),
              borderRadius: BorderRadius.circular(35),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFDB2C2C), Color(0x00E05F5F)],
                stops: [0, 1],
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    '${ticket.currentStation} -> ${ticket.arrivalStation}',
                    style: GoogleFonts.inika(
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                      color: Color(0xFFDB2C2C),
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Train Number: ${ticket.trainNumber}',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Current Station: ${ticket.currentStation}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Arrival Station: ${ticket.arrivalStation}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Ticket Price: ${widget.totalPrice} EGP',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Trip Duration: ${ticket.tripDuration}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Arrival Time to Station: ${ticket.arrivalTimeToStation}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Arrival Time to Destination Station: ${ticket.arrivalTimeToDestinationStation}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Train Type: ${ticket.type}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 20),
                  Container(
                    padding: EdgeInsets.all(10),
                    color: Colors.white, // Adjust as needed
                    child: Column(
                      children: [
                        QrImageView(
                          data: _generateQrData(ticket),
                          version: QrVersions.auto,
                          size: 200.0,
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Scan QR code for details',
                          style: TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  String _generateQrData(TicketData ticket) {
    // Example: Concatenate relevant ticket details for QR code data
    return '${ticket.trainNumber},${ticket.currentStation},${ticket.arrivalStation}';
  }
}
