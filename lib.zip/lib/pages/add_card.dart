import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/firestore_service.dart';
import '../services/paymob/ticketdata/ticket_data.dart';
import 'my_ticket.dart';

class AddCard extends StatefulWidget {
  final int totalPrice;
  final Map<String, dynamic> trainData;

  AddCard({
    required this.totalPrice,
    required this.trainData,
  });

  @override
  _AddCardState createState() => _AddCardState();
}

class _AddCardState extends State<AddCard> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _cardHolderNameController =
      TextEditingController();
  final TextEditingController _cardNumberController = TextEditingController();
  final TextEditingController _expiryDateController = TextEditingController();
  final TextEditingController _cvcController = TextEditingController();

  @override
  void dispose() {
    _cardHolderNameController.dispose();
    _cardNumberController.dispose();
    _expiryDateController.dispose();
    _cvcController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: WillPopScope(
        onWillPop: () async {
          Navigator.of(context).pop();
          return true;
        },
        child: SingleChildScrollView(
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xFFFFFFFF),
              borderRadius: BorderRadius.circular(20),
            ),
            padding: EdgeInsets.fromLTRB(23, 42, 24, 40),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTitle(context),
                  SizedBox(height: 30),
                  Text(
                    'Total Price: ${widget.totalPrice} EGP',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  _buildTrainInfo('Train Number', 'trainNumber'),
                  _buildTrainInfo('Arrival Station', 'arrivalStation'),
                  _buildTrainInfo('Current Station', 'currentStation'),
                  SizedBox(height: 32),
                  _buildInputField('CARD HOLDER NAME', 'Enter card holder name',
                      _cardHolderNameController),
                  _buildInputField(
                      'CARD NUMBER', 'Enter card number', _cardNumberController,
                      maxLength: 19, format: _CardNumberFormatter()),
                  _buildExpiryAndCVC(),
                  SizedBox(height: 48),
                  _buildButtons(context),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTitle(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        GestureDetector(
          onTap: () {
            Navigator.pop(context); // Navigate back to SelectSeat
          },
          child: SvgPicture.asset(
              'assets/vectors/back_11_x2.svg'), // Adjust the path if needed
        ),
        Text(
          'Add Card',
          style: GoogleFonts.getFont(
            'Inika',
            fontWeight: FontWeight.w400,
            fontSize: 18,
            color: Color(0xFF0D0D0D),
          ),
        ),
        SizedBox(width: 24), // To balance the row
      ],
    );
  }

  Widget _buildTrainInfo(String label, String key) {
    final String? value = widget.trainData[key];
    return Text(
      '$label: ${value ?? 'Not specified'}',
      style: TextStyle(fontSize: 16),
    );
  }

  Widget _buildInputField(
      String label, String hintText, TextEditingController controller,
      {int? maxLength, TextInputFormatter? format}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.getFont(
            'Inika',
            fontWeight: FontWeight.w400,
            fontSize: 14,
            height: 1.7,
            color: Color(0xFFA0A5BA),
          ),
        ),
        SizedBox(height: 8),
        TextFormField(
          controller: controller,
          inputFormatters: format != null ? [format] : null,
          maxLength: maxLength,
          decoration: InputDecoration(
            counterText: '', // Hide character counter
            filled: true,
            fillColor: Color(0xFFF0F5FA),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
            contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
            hintText: hintText,
            hintStyle: TextStyle(
              fontFamily: 'Inika',
              fontWeight: FontWeight.w400,
              fontSize: 16,
              color: Color(0xFF32343E),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter ${label.toLowerCase()}';
            }
            return null;
          },
        ),
        SizedBox(height: 16), // Add some space between fields
      ],
    );
  }

  Widget _buildExpiryAndCVC() {
    return Row(
      children: [
        Expanded(
          child: _buildInputField(
              'EXPIRE DATE', 'mm/yyyy', _expiryDateController,
              maxLength: 7, format: _ExpiryDateFormatter()),
        ),
        SizedBox(width: 14),
        Expanded(
          child: _buildInputField('CVC', 'Enter CVC', _cvcController,
              maxLength: 3, format: FilteringTextInputFormatter.digitsOnly),
        ),
      ],
    );
  }

  Widget _buildButtons(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            margin: EdgeInsets.only(right: 23),
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFF121212)),
              borderRadius: BorderRadius.circular(14),
              color: Color(0x21FFFFFF),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context); // Navigate back to SelectSeat
              },
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontFamily: 'Inika',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  letterSpacing: -0.4,
                  color: Color(0x820E0E0E),
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: Color(0xFFFF0000),
              boxShadow: [
                BoxShadow(
                  color: Color(0x40000000),
                  offset: Offset(0, 4),
                  blurRadius: 2,
                ),
              ],
            ),
            child: TextButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  _simulatePaymentSuccess(context);
                }
              },
              child: Text(
                'Pay Now',
                style: TextStyle(
                  fontFamily: 'Inika',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  letterSpacing: -0.4,
                  color: Color(0xFFFFFFFF),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _simulatePaymentSuccess(BuildContext context) async {
    // Simulate payment success
    final FirestoreService firestoreService = FirestoreService();

    TicketData ticketData = TicketData(
      arrivalStation: widget.trainData['arrivalStation'] ?? '',
      currentStation: widget.trainData['currentStation'] ?? '',
      ticketPrice: widget.totalPrice,
      tripDuration: widget.trainData['tripDuration'] ?? '',
      type: widget.trainData['type'] ?? '',
      date: widget.trainData['date'] ?? '',
      arrivalTimeToStation: widget.trainData['arrivalTimeToStation'] ?? '',
      arrivalTimeToDestinationStation:
          widget.trainData['arrivalTimeToDestinationStation'] ?? '',
      trainNumber: widget.trainData['trainNumber'] ?? '',
    );

    await firestoreService.saveTicketToSubcollection(ticketData);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MyTicket(
          trainNumber: ticketData.trainNumber,
          totalPrice: ticketData.ticketPrice,
          date: ticketData.date,
        ),
      ),
    );
  }
}

class _CardNumberFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    String newText = newValue.text.replaceAll(RegExp(r'\D'), '');
    String formattedText = '';

    for (int i = 0; i < newText.length; i++) {
      if (i % 4 == 0 && i != 0) {
        formattedText += ' ';
      }
      formattedText += newText[i];
    }

    return TextEditingValue(
      text: formattedText,
      selection: TextSelection.collapsed(offset: formattedText.length),
    );
  }
}

class _ExpiryDateFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    String newText = newValue.text.replaceAll(RegExp(r'\D'), '');
    String formattedText = '';

    for (int i = 0; i < newText.length; i++) {
      if (i == 2) {
        formattedText += '/';
      }
      formattedText += newText[i];
    }

    return TextEditingValue(
      text: formattedText,
      selection: TextSelection.collapsed(offset: formattedText.length),
    );
  }
}
